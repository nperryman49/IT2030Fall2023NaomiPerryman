﻿using Microsoft.EntityFrameworkCore;

using NaomiRetroCloset.Models;

namespace NaomiRetroCloset.Data
{
    public class NaomiRetroClosetContext : DbContext
    {
        public NaomiRetroClosetContext(DbContextOptions<NaomiRetroClosetContext> options)
            : base(options) { }
        public DbSet<ProductModel> DbProduct { get; set; } = null!;
        public DbSet<ContactModel> DbContact { get; set; } = null!;
    
    }
}
