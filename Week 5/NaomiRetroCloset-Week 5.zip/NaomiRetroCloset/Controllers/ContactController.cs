﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NaomiRetroCloset.Models;

namespace NaomiRetroCloset.Controllers
{
    public class ContactController : Controller
    {
        [HttpGet]
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Index(ContactModel model)
        {
            return View(model);
        }

            

       
        
    }
}
