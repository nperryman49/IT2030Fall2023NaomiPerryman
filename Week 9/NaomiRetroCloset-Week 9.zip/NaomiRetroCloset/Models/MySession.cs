﻿namespace NaomiRetroCloset.Models
{
    public class MySession
    {
        public string FirstName { get; set; } 

        public string LastName { get; set; } = string.Empty;

        public string Course { get; set; }=string.Empty;

        public int FavNum { get; set; } 

    }
}
//FirstName (string data type), LastName (string data type), Course (string data type), and FavNum (int data type). 