﻿using System.ComponentModel.DataAnnotations;


namespace NaomiRetroCloset.Models
{
    public class ContactModel
    {
        [Required(ErrorMessage = "Please enter a first name under 30 characters. It must not contain special characters or numbers.")]
        [RegularExpression("[A-Za-z]+$", ErrorMessage = "Please enter a first name under 30 characters. It must not contain special characters or numbers.")]
        [StringLength(30)]
        public string? FirstName { get; set; }

        [Required(ErrorMessage = "Please enter a last name under 30 characters. It must not contain special characters or numbers.")]
        [RegularExpression("[A-Za-z]+$", ErrorMessage = "Please enter a first name under 30 characters. It must not contain special characters or numbers.")]
        [StringLength(30)]
        public string? LastName { get; set; }

        [Required(ErrorMessage = "Please enter an address")]
        public string? Address { get; set; }

        [Required(ErrorMessage = "Please enter a phone number containing 10 numerical characters.")]
        [RegularExpression("[0-9]+$", ErrorMessage ="Phone number must contain no more than 10 numerical digits")]
        [StringLength(10)]
        public string? Phone { get; set; }

        [Required(ErrorMessage = "Please enter a valid email address")]
        [RegularExpression(@"^[^@\s]+@[^@\s]+\.[^@\s]+$", ErrorMessage="Please enter a valid email address.")]
        public string? Email { get; set; }
        
        
        [Required(ErrorMessage = "Please enter a message")]
        public string? Message { get; set; }
    }
}
//FirstName, LastName, Address, Phone, Email, and Message