﻿namespace NaomiRetroCloset.Models
{
    public class ProductData
    {
        public static List<ProductModel>GetProducts()
        {
            List<ProductModel> products = new List<ProductModel>
            {
                new ProductModel
                {
                    ProductId = 1,
                    ProductName= "Women's Top",
                    ProductDescription="Tops",
                    ProductImage="/Images/top1.webp",
                    ProductPrice=17
                },
                new ProductModel
                {
                    ProductId = 2,
                    ProductName= "Women's Top",
                    ProductDescription="Tops",
                    ProductImage="/Images/top2.webp",
                    ProductPrice=12
                },
                new ProductModel
                {
                    ProductId = 3,
                    ProductName= "Mid-length Dress",
                    ProductDescription="Dress",
                    ProductImage="/Images/dress1.jpg",
                    ProductPrice=27
                },
                new ProductModel
                {
                    ProductId = 4,
                    ProductName= "Mid-length Dress",
                    ProductDescription="Dress",
                    ProductImage="/Images/dress2.jpg",
                    ProductPrice=24
                },
                new ProductModel
                {
                    ProductId = 5,
                    ProductName= "Low heel shoes",
                    ProductDescription="Shoes",
                    ProductImage="/Images/shoes1.jpg",
                    ProductPrice=18
                },
                new ProductModel
                {
                    ProductId = 6,
                    ProductName= "Flats",
                    ProductDescription="Shoes",
                    ProductImage="/Images/shoes2.jpg",
                    ProductPrice=14
                }
            };
            return products;
        }
        public static ProductModel GetProduct (int id)
        {
            List<ProductModel> products = ProductData.GetProducts();
            foreach(ProductModel product in products)
            {
                if (product.ProductId == id)
                    return product;
            }
            return new ProductModel();
        }
    }
}
